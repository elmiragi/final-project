


// const data = JSON.parse(`[{
//     "name": "Leanne Graham",
//     "email": "Sincere@april.biz"
// },{
//     "id": 2,
//     "name": "Ervin Howell",
//     "email": "Katrin@may.bz"
// },{
//     "id": 3,
//     "email": "Nathan@yesenia.net"
// },{
//     "id": 4,
//     "name": "Patricia Lebsack",
//     "email": "Julianne.OConner@kory.org"
// },{
//     "id": 5,
//     "email": "Lucio_Hettinger@annie.ca"
// }]`);

// function validateUsers(users) {
//     try {
//         let index = 0;
//         users.forEach(user => {
//             try{
//                 index += 1;
//                if ((user.id==undefined) || (user.name==undefined) || (user.email==undefined)) {
//                     throw new Error(`Данные некорректны`)
//                }else{
//                     console.log(`${index}. Данные корректны: id: ${user.id}, name: ${user.name}, email: ${user.email}`);
//                }
//             }catch(error) {
//                 console.error(`${index}. Ошибка:`, error.message);
//             }
//         })
//     } catch (error) {
//         console.error('Ошибка обработки:', error.message);
//     }
// }
// validateUsers(data);

